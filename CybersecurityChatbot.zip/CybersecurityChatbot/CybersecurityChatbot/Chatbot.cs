using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using Microsoft.ML;
using Microsoft.ML.Transforms.Text;

namespace CybersecurityChatbot
{
    public class Chatbot
    {
        private readonly Dictionary<string, List<string>> _keywordResponses;
        private readonly List<string> _generalResponses;
        private readonly Dictionary<string, string> _sentimentResponses;
        private readonly UserInfo _userInfo;
        private readonly MLContext _mlContext;
        private PredictionEngine<SentimentData, SentimentPrediction> _predictionEngine;

        public Chatbot()
        {
            _mlContext = new MLContext();

            _keywordResponses = new Dictionary<string, List<string>>
            {
                ["password"] = new List<string>
                {
                    "Make sure to use strong, unique passwords for each account. Avoid using personal details in your passwords.",
                    "Consider using a password manager to generate and store complex passwords securely.",
                    "Enable two-factor authentication along with strong passwords for better security."
                },
                ["scam"] = new List<string>
                {
                    "Scams often try to create urgency. Always verify unexpected requests for money or information.",
                    "Never share personal or financial information with unsolicited callers or emails.",
                    "If an offer seems too good to be true, it probably is a scam."
                },
                ["privacy"] = new List<string>
                {
                    "Regularly review privacy settings on your social media accounts and apps.",
                    "Be cautious about what personal information you share online - it can be used for identity theft.",
                    "Use private browsing modes and VPNs when accessing sensitive information on public networks."
                },
                ["phishing"] = new List<string>
                {
                    "Be cautious of emails asking for personal information. Scammers often disguise themselves as trusted organizations.",
                    "Check the sender's email address carefully - phishing emails often use slight misspellings of legitimate addresses.",
                    "Hover over links before clicking to see the actual URL. If it looks suspicious, don't click."
                },
                ["malware"] = new List<string>
                {
                    "Keep your antivirus software updated and run regular scans to protect against malware.",
                    "Never download attachments or click links from unknown sources as they may contain malware.",
                    "Be wary of 'free' software downloads which might bundle malware with the application."
                }
            };

            _generalResponses = new List<string>
            {
                "Cybersecurity is important for everyone. Would you like to learn about passwords, scams, or privacy?",
                "Staying safe online is crucial in today's digital world. What specific topic interests you?",
                "I can help with various cybersecurity topics. What would you like to discuss?"
            };

            _userInfo = new UserInfo();

            _sentimentResponses = new Dictionary<string, string>
            {
                ["positive"] = "I'm glad you're enthusiastic about cybersecurity! ",
                ["neutral"] = "Let me share some information about that. ",
                ["negative"] = "I understand this can be concerning. Let me help you with that. "
            };

            InitializeSentimentAnalysis();
        }

        private void InitializeSentimentAnalysis()
        {
            var data = new List<SentimentData>();
            var dataView = _mlContext.Data.LoadFromEnumerable(data);
            var pipeline = _mlContext.Transforms.Text.FeaturizeText("Features", nameof(SentimentData.Text));
            var model = pipeline.Fit(dataView);
            _predictionEngine = _mlContext.Model.CreatePredictionEngine<SentimentData, SentimentPrediction>(model);
        }

        private string DetectSentiment(string text)
        {
            if (text.Contains("!") || text.ToLower().Contains("great") || text.ToLower().Contains("awesome"))
                return "positive";
            if (text.ToLower().Contains("worried") || text.ToLower().Contains("concerned") || text.ToLower().Contains("frustrated"))
                return "negative";
            return "neutral";
        }

        private void RememberUserInfo(string text)
        {
            var nameMatch = Regex.Match(text, @"(?:my name is|i'm|I am) ([A-Za-z]+)", RegexOptions.IgnoreCase);
            if (nameMatch.Success && string.IsNullOrEmpty(_userInfo.Name))
            {
                _userInfo.Name = nameMatch.Groups[1].Value;
                _userInfo.Name = char.ToUpper(_userInfo.Name[0]) + _userInfo.Name.Substring(1).ToLower();
            }

            var interestMatch = Regex.Match(text, @"(?:interested in|like to know about|learn about) (\w+)", RegexOptions.IgnoreCase);
            if (interestMatch.Success)
            {
                string interest = interestMatch.Groups[1].Value.ToLower();
                if (_keywordResponses.ContainsKey(interest) && !_userInfo.Interests.Contains(interest))
                {
                    _userInfo.Interests.Add(interest);
                }
            }
        }

        public string GenerateResponse(string userInput)
        {
            if (string.IsNullOrWhiteSpace(userInput))
                return "I didn't receive any input. Could you please repeat that?";

            RememberUserInfo(userInput);

            if (Regex.IsMatch(userInput, @"\b(hi|hello|hey)\b", RegexOptions.IgnoreCase))
            {
                string greeting = !string.IsNullOrEmpty(_userInfo.Name) ? $"Hello {_userInfo.Name}! " : "Hello! ";
                return greeting + _generalResponses[new Random().Next(_generalResponses.Count)];
            }

            if (Regex.IsMatch(userInput, @"\b(thanks|thank you|appreciate)\b", RegexOptions.IgnoreCase))
            {
                return "You're welcome! Stay safe online. Is there anything else you'd like to know about cybersecurity?";
            }

            string sentiment = DetectSentiment(userInput);
            string sentimentPrefix = _sentimentResponses.ContainsKey(sentiment) ? _sentimentResponses[sentiment] : "";

            foreach (var keyword in _keywordResponses.Keys)
            {
                if (Regex.IsMatch(userInput, $@"\b{keyword}\b", RegexOptions.IgnoreCase))
                {
                    _userInfo.PreviousTopics.Add(keyword);
                    string response = _keywordResponses[keyword][new Random().Next(_keywordResponses[keyword].Count)];

                    if (_userInfo.Interests.Contains(keyword))
                    {
                        return $"{sentimentPrefix}As someone interested in {keyword}, you might find this particularly important: {response}";
                    }
                    return sentimentPrefix + response;
                }
            }

            if (Regex.IsMatch(userInput, @"\b(more|another|additional)\b", RegexOptions.IgnoreCase) && _userInfo.PreviousTopics.Count > 0)
            {
                string lastTopic = _userInfo.PreviousTopics[^1];
                if (_keywordResponses.ContainsKey(lastTopic))
                {
                    return sentimentPrefix + _keywordResponses[lastTopic][new Random().Next(_keywordResponses[lastTopic].Count)];
                }
            }

            if (!string.IsNullOrEmpty(_userInfo.Name))
            {
                return $"I'm not sure I understand, {_userInfo.Name}. Could you try rephrasing or asking about a specific cybersecurity topic?";
            }
            return "I'm not sure I understand. Could you try rephrasing or asking about a specific cybersecurity topic like passwords, scams, or privacy?";
        }
    }

    public class UserInfo
    {
        public string Name { get; set; }
        public List<string> Interests { get; set; } = new List<string>();
        public List<string> PreviousTopics { get; set; } = new List<string>();
    }

    public class SentimentData
    {
        public string Text { get; set; }
        public bool Label { get; set; }
    }

    public class SentimentPrediction
    {
        public bool Prediction { get; set; }
    }
}
